import{g as l}from"./coupons-C3couXkM.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))a(e);new MutationObserver(e=>{for(const o of e)if(o.type==="childList")for(const c of o.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&a(c)}).observe(document,{childList:!0,subtree:!0});function i(e){const o={};return e.integrity&&(o.integrity=e.integrity),e.referrerPolicy&&(o.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?o.credentials="include":e.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function a(e){if(e.ep)return;e.ep=!0;const o=i(e);fetch(e.href,o)}})();const n=document.getElementById("content");async function v(){const[s]=await chrome.tabs.query({active:!0,currentWindow:!0});return s}async function p(s){return new Promise(t=>{chrome.runtime.sendMessage({type:"GET_TAB_STATE",tabId:s},t)})}function d(){n.innerHTML=`
    <div class="status-card">
      <div class="status-icon">🛒</div>
      <div class="status-title">Browse to a shopping site</div>
      <div class="status-subtitle">CouponSnap auto-detects checkout pages and applies coupons for you.</div>
    </div>
  `}function u(s){const t=l(s);t?n.innerHTML=`
      <div class="status-card">
        <div class="status-icon">🏷️</div>
        <div class="status-title">${t.codes.length} coupon${t.codes.length>1?"s":""} available for ${s}</div>
        <div class="status-subtitle">Navigate to checkout and CouponSnap will apply them automatically.</div>
        <div class="coupon-list">
          ${t.codes.map(i=>`
            <div class="coupon-item">
              <span class="coupon-code">${i.code}</span>
              <span class="coupon-discount">${i.discount}</span>
            </div>
          `).join("")}
        </div>
      </div>
      <button class="btn-try" id="btn-goto-checkout" disabled>Go to checkout to apply</button>
    `:n.innerHTML=`
      <div class="status-card">
        <div class="status-icon">🔍</div>
        <div class="status-title">No coupons for this site</div>
        <div class="status-subtitle">We don't have coupons for <strong>${s}</strong> yet. More stores coming soon!</div>
      </div>
    `}function f(s,t){var i;if(!s.hasCoupons){n.innerHTML=`
      <div class="status-card">
        <div class="status-icon">😔</div>
        <div class="status-title">No coupons found</div>
        <div class="status-subtitle">We don't have any coupons for ${s.hostname} right now.</div>
      </div>
    `;return}n.innerHTML=`
    <div class="status-card">
      <div class="status-icon">✂️</div>
      <div class="status-title">Checkout detected!</div>
      <div class="status-subtitle">Found ${s.couponCount} coupon${s.couponCount>1?"s":""} for ${s.hostname}</div>
    </div>
    <button class="btn-try" id="btn-apply">Try ${s.couponCount} Coupon${s.couponCount>1?"s":""} Now</button>
  `,(i=document.getElementById("btn-apply"))==null||i.addEventListener("click",async()=>{const a=document.getElementById("btn-apply");a.disabled=!0,a.innerHTML='<span class="loading-dots">Trying coupons</span>',await chrome.tabs.sendMessage(t,{type:"TRY_COUPONS"}),setTimeout(()=>r(),4e3)})}function y(s){n.innerHTML=`
    <div class="success-badge">
      <div class="code">${s.appliedCode}</div>
      <div class="desc">${s.savings?`Saved ${s.savings}`:"Coupon applied!"}</div>
      ${s.savings?`<span class="savings-pill">${s.savings} OFF</span>`:""}
    </div>
    <div class="status-card">
      <div class="status-icon">🎉</div>
      <div class="status-title">Coupon applied!</div>
      <div class="status-subtitle">CouponSnap saved you money automatically.</div>
    </div>
  `}function g(){n.innerHTML=`
    <div class="status-card">
      <div class="status-icon">😞</div>
      <div class="status-title">No codes worked</div>
      <div class="status-subtitle">We tried all available coupons but none were accepted. They may be expired.</div>
    </div>
  `}function m(s){n.innerHTML=`
    <div class="status-card">
      <div class="status-icon">⚡</div>
      <div class="status-title loading-dots">Trying coupons</div>
      <div class="status-subtitle">${s?`Testing: <code>${s}</code>`:"Applying coupon codes automatically..."}</div>
    </div>
  `}function b(s){n.innerHTML=`
    <div class="status-card">
      <div class="status-icon">🔍</div>
      <div class="status-title">Coupon field not found</div>
      <div class="status-subtitle">Couldn't locate the coupon input on ${s}. Right-click the page and select <strong>CouponSnap: Try Coupon Codes</strong> to retry.</div>
    </div>
  `}async function r(){try{const s=await v();if(!(s!=null&&s.id)||!(s!=null&&s.url)){d();return}if(!s.url.startsWith("http")){d();return}const t=new URL(s.url).hostname,i=await p(s.id);if(!i){u(t);return}switch(i.status){case"found":f(i,s.id);break;case"none":u(t);break;case"trying":m(i.tryingCode);break;case"no_field":b(i.hostname);break;case"applied":y(i);break;case"failed":g();break;default:u(t)}}catch{d()}}r();
