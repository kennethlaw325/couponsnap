import{g as y,a as g,s as w}from"./coupons-BZs23IKa.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))a(s);new MutationObserver(s=>{for(const n of s)if(n.type==="childList")for(const d of n.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&a(d)}).observe(document,{childList:!0,subtree:!0});function i(s){const n={};return s.integrity&&(n.integrity=s.integrity),s.referrerPolicy&&(n.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?n.credentials="include":s.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function a(s){if(s.ep)return;s.ep=!0;const n=i(s);fetch(s.href,n)}})();const r=document.getElementById("content"),u=document.getElementById("tabs"),E=document.getElementById("deals-count"),$=document.getElementById("codes-count");let l="deals";function C(){document.querySelectorAll(".tab-btn").forEach(e=>{e.addEventListener("click",()=>{l=e.dataset.tab,document.querySelectorAll(".tab-btn").forEach(t=>t.classList.toggle("active",t===e)),document.querySelectorAll(".tab-panel").forEach(t=>t.classList.toggle("active",t.id===`panel-${l}`))})})}async function T(){const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});return e}async function h(e){return new Promise(t=>{chrome.runtime.sendMessage({type:"GET_TAB_STATE",tabId:e},t)})}function f(){u.style.display="none",r.innerHTML=`
    <div class="status-card">
      <div class="status-icon">🛒</div>
      <div class="status-title">Browse to a shopping site</div>
      <div class="status-subtitle">CouponSnap finds deals and coupon codes automatically as you shop.</div>
    </div>
  `}async function L(e,t,i){const a=y(e),s=(a==null?void 0:a.deals)||[],n=await g(e);if(!s.length&&!n.length){u.style.display="none",r.innerHTML=`
      <div class="status-card">
        <div class="status-icon">🔍</div>
        <div class="status-title">No savings found for this site</div>
        <div class="status-subtitle">We don't have deals or codes for <strong>${e}</strong> yet. Know a code? Submit it below!</div>
      </div>
      ${p()}
    `,b(e);return}u.style.display="flex",E.textContent=s.length,$.textContent=n.length,(t==null?void 0:t.status)==="found"&&n.length?l="codes":s.length?l="deals":l="codes",document.querySelectorAll(".tab-btn").forEach(m=>{m.classList.toggle("active",m.dataset.tab===l)});const d=x(s),o=await B(n,t);r.innerHTML=`
    <div class="tab-panel ${l==="deals"?"active":""}" id="panel-deals">
      ${d}
    </div>
    <div class="tab-panel ${l==="codes"?"active":""}" id="panel-codes">
      ${o}
      ${p()}
    </div>
  `,A(e,a),N(i),I(),b(e)}function x(e,t,i){return e.length?`<div class="deal-list">${e.map((s,n)=>`
    <div class="deal-card">
      <div class="deal-info">
        <span class="deal-discount">${s.discount}</span>
        <div class="deal-desc">${s.desc}</div>
      </div>
      <button class="btn-shop" data-deal-index="${n}">Shop →</button>
    </div>
  `).join("")}</div>`:'<div class="empty-state"><div class="icon">🏷️</div>No deals available right now.</div>'}function A(e,t){document.querySelectorAll(".btn-shop").forEach(i=>{i.addEventListener("click",async()=>{const[a]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(a!=null&&a.url))return;let s=a.url;try{const n=new URL(s),d=P(t);d&&(n.searchParams.set(d.affiliateParam||d.param,d.affiliateTag||d.tag),s=n.toString())}catch{}chrome.tabs.update(a.id,{url:s}),window.close()})})}function P(e){return e!=null&&e.affiliateTag?{affiliateParam:e.affiliateParam,affiliateTag:e.affiliateTag}:null}async function B(e,t,i,a){if(!e.length)return'<div class="empty-state"><div class="icon">🏷️</div>No codes yet — be the first to submit one!</div>';let s="";(t==null?void 0:t.status)==="found"?s=`<button class="btn-primary" id="btn-apply">⚡ Try ${e.length} Code${e.length>1?"s":""} Automatically</button>`:(t==null?void 0:t.status)==="trying"?s='<button class="btn-primary" disabled><span class="loading-dots">Trying codes</span></button>':(t==null?void 0:t.status)==="applied"?s=`
      <div class="success-badge">
        <div class="code">${t.appliedCode}</div>
        <div class="desc">${t.savings?`Saved ${t.savings}`:"Coupon applied!"}</div>
        ${t.savings?`<span class="savings-pill">${t.savings} OFF</span>`:""}
      </div>
    `:(t==null?void 0:t.status)==="failed"&&(s=`
      <div class="status-card">
        <div class="status-icon">😞</div>
        <div class="status-title">No codes worked this time</div>
        <div class="status-subtitle">Know a working code? Submit it below!</div>
      </div>
    `);const n=e.map(o=>`
    <div class="code-card ${o.userSubmitted?"user-submitted":""}">
      <div class="code-meta">
        <div class="code-badge">${o.code}</div>
        <div class="code-desc">${o.desc}</div>
        ${o.userSubmitted?'<div class="user-badge">👤 Community</div>':""}
      </div>
      <div class="code-actions">
        <span class="code-discount">${o.discount}</span>
        <button class="btn-copy" data-code="${o.code}" title="Copy code">📋</button>
      </div>
    </div>
  `).join(""),d=(t==null?void 0:t.status)==="no_field"?'<div class="copy-hint">⚠️ Auto-apply not available here — copy a code and paste it at checkout</div>':"";return`
    ${s}
    ${d}
    <div class="code-list" style="margin-top:${s||d?"10px":"0"}">${n}</div>
  `}function I(){document.querySelectorAll(".btn-copy").forEach(e=>{e.addEventListener("click",async()=>{const t=e.dataset.code;try{await navigator.clipboard.writeText(t);const i=e.textContent;e.textContent="✓",e.style.color="#22c55e",setTimeout(()=>{e.textContent=i,e.style.color=""},1500)}catch{const i=document.createElement("input");i.value=t,document.body.appendChild(i),i.select(),document.execCommand("copy"),document.body.removeChild(i),e.textContent="✓",setTimeout(()=>{e.textContent="📋"},1500)}})})}function N(e,t){const i=document.getElementById("btn-apply");!i||!e||i.addEventListener("click",async()=>{i.disabled=!0,i.innerHTML='<span class="loading-dots">Trying codes</span>',await chrome.tabs.sendMessage(e,{type:"TRY_COUPONS"}),setTimeout(()=>v(),4e3)})}function p(e){return`
    <div class="submit-section">
      <div class="submit-title">💡 Know a working code? Share it!</div>
      <div class="submit-row">
        <input type="text" class="input-code" id="input-submit-code"
          placeholder="e.g. SAVE20"
          maxlength="30"
          autocomplete="off"
          spellcheck="false" />
        <button class="btn-submit" id="btn-submit-code">Submit</button>
      </div>
      <div class="submit-feedback" id="submit-feedback"></div>
    </div>
  `}function b(e){const t=document.getElementById("input-submit-code"),i=document.getElementById("btn-submit-code"),a=document.getElementById("submit-feedback");!t||!i||!a||(t.addEventListener("input",()=>{const s=t.selectionStart;t.value=t.value.toUpperCase().replace(/[^A-Z0-9\-_]/g,""),t.setSelectionRange(s,s)}),i.addEventListener("click",async()=>{const s=t.value.trim();if(!s||s.length<2){c(a,"Enter a valid code","error");return}i.disabled=!0,await w(e,s,"")?(t.value="",c(a,`✓ "${s}" saved! It'll be tried next checkout.`,"success"),setTimeout(()=>v(),1500)):c(a,"This code is already in the list.","error"),i.disabled=!1}),t.addEventListener("keydown",s=>{s.key==="Enter"&&i.click()}))}function c(e,t,i){e.textContent=t,e.className=`submit-feedback ${i}`,setTimeout(()=>{e.textContent="",e.className="submit-feedback"},4e3)}async function v(){try{const e=await T();if(!(e!=null&&e.id)||!(e!=null&&e.url)||!e.url.startsWith("http")){f();return}const t=new URL(e.url).hostname,i=await h(e.id);await L(t,i,e.id)}catch{f()}}C();v();
