import{g as C,a as $,s as T}from"./coupons-BZs23IKa.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))o(s);new MutationObserver(s=>{for(const i of s)if(i.type==="childList")for(const a of i.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&o(a)}).observe(document,{childList:!0,subtree:!0});function n(s){const i={};return s.integrity&&(i.integrity=s.integrity),s.referrerPolicy&&(i.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?i.credentials="include":s.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function o(s){if(s.ep)return;s.ep=!0;const i=n(s);fetch(s.href,i)}})();const r="https://github.com/kennethlaw325/couponsnap/releases/latest",x="https://mail.google.com/mail/?view=cm&to=support@couponsnap.app&su=CouponSnap%20Beta%20Feedback&body=Rating%20(1-5)%3A%20%0D%0AWhat%20I%20like%20most%3A%20%0D%0AWhat%20to%20improve%3A%20%0D%0ATestimonial%20(can%20we%20share%3F)%3A%20%0D%0AEmail%20for%20updates%20(optional)%3A%20",m=document.getElementById("content"),v=document.getElementById("tabs"),L=document.getElementById("deals-count"),A=document.getElementById("codes-count");let c="deals";function B(){document.querySelectorAll(".tab-btn").forEach(e=>{e.addEventListener("click",()=>{c=e.dataset.tab,document.querySelectorAll(".tab-btn").forEach(t=>t.classList.toggle("active",t===e)),document.querySelectorAll(".tab-panel").forEach(t=>t.classList.toggle("active",t.id===`panel-${c}`))})})}async function I(){const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});return e}async function _(e){return new Promise(t=>{chrome.runtime.sendMessage({type:"GET_TAB_STATE",tabId:e},t)})}function b(){v.style.display="none",m.innerHTML=`
    <div class="status-card">
      <div class="status-icon">🛒</div>
      <div class="status-title">Browse to a shopping site</div>
      <div class="status-subtitle">CouponSnap finds deals and coupon codes automatically as you shop.</div>
    </div>
  `}async function F(e,t,n){const o=C(e),s=(o==null?void 0:o.deals)||[],i=await $(e);if(!s.length&&!i.length){v.style.display="none",m.innerHTML=`
      <div class="status-card">
        <div class="status-icon">🔍</div>
        <div class="status-title">No savings found for this site</div>
        <div class="status-subtitle">We don't have deals or codes for <strong>${e}</strong> yet. Know a code? Submit it below!</div>
      </div>
      ${g()}
    `,y(e);return}v.style.display="flex",L.textContent=s.length,A.textContent=i.length,(t==null?void 0:t.status)==="found"&&i.length?c="codes":s.length?c="deals":c="codes",document.querySelectorAll(".tab-btn").forEach(l=>{l.classList.toggle("active",l.dataset.tab===c)});const a=P(s),d=await O(i,t,n,e);m.innerHTML=`
    <div class="tab-panel ${c==="deals"?"active":""}" id="panel-deals">
      ${a}
    </div>
    <div class="tab-panel ${c==="codes"?"active":""}" id="panel-codes">
      ${d}
      ${g()}
    </div>
  `,U(e,o),D(n),q(),H(),y(e)}function P(e,t,n){return e.length?`<div class="deal-list">${e.map((s,i)=>`
    <div class="deal-card">
      <div class="deal-info">
        <span class="deal-discount">${s.discount}</span>
        <div class="deal-desc">${s.desc}</div>
      </div>
      <button class="btn-shop" data-deal-index="${i}">Shop →</button>
    </div>
  `).join("")}</div>`:'<div class="empty-state"><div class="icon">🏷️</div>No deals available right now.</div>'}function U(e,t){document.querySelectorAll(".btn-shop").forEach(n=>{n.addEventListener("click",async()=>{const[o]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(o!=null&&o.url))return;let s=o.url;try{const i=new URL(s),a=R(t);a&&(i.searchParams.set(a.affiliateParam||a.param,a.affiliateTag||a.tag),s=i.toString())}catch{}chrome.tabs.update(o.id,{url:s}),window.close()})})}function R(e){return e!=null&&e.affiliateTag?{affiliateParam:e.affiliateParam,affiliateTag:e.affiliateTag}:null}async function O(e,t,n,o){if(!e.length)return'<div class="empty-state"><div class="icon">🏷️</div>No codes yet — be the first to submit one!</div>';let s="";(t==null?void 0:t.status)==="found"?s=`<button class="btn-primary" id="btn-apply">⚡ Try ${e.length} Code${e.length>1?"s":""} Automatically</button>`:(t==null?void 0:t.status)==="trying"?s='<button class="btn-primary" disabled><span class="loading-dots">Trying codes</span></button>':(t==null?void 0:t.status)==="applied"?s=`
      <div class="success-badge">
        <div class="code">${t.appliedCode}</div>
        <div class="desc">${t.savings?`Saved ${t.savings}`:"Coupon applied!"}</div>
        ${t.savings?`<span class="savings-pill">${t.savings} OFF</span>`:""}
      </div>
      ${N(t.savings,o)}
    `:(t==null?void 0:t.status)==="failed"&&(s=`
      <div class="status-card">
        <div class="status-icon">😞</div>
        <div class="status-title">No codes worked this time</div>
        <div class="status-subtitle">Know a working code? Submit it below!</div>
      </div>
    `);const i=e.map(d=>`
    <div class="code-card ${d.userSubmitted?"user-submitted":""}">
      <div class="code-meta">
        <div class="code-badge">${d.code}</div>
        <div class="code-desc">${d.desc}</div>
        ${d.userSubmitted?'<div class="user-badge">👤 Community</div>':""}
      </div>
      <div class="code-actions">
        <span class="code-discount">${d.discount}</span>
        <button class="btn-copy" data-code="${d.code}" title="Copy code">📋</button>
      </div>
    </div>
  `).join(""),a=(t==null?void 0:t.status)==="no_field"?'<div class="copy-hint">⚠️ Auto-apply not available here — copy a code and paste it at checkout</div>':"";return`
    ${s}
    ${a}
    <div class="code-list" style="margin-top:${s||a?"10px":"0"}">${i}</div>
  `}function q(){document.querySelectorAll(".btn-copy").forEach(e=>{e.addEventListener("click",async()=>{const t=e.dataset.code;try{await navigator.clipboard.writeText(t);const n=e.textContent;e.textContent="✓",e.style.color="#22c55e",setTimeout(()=>{e.textContent=n,e.style.color=""},1500)}catch{const n=document.createElement("input");n.value=t,document.body.appendChild(n),n.select(),document.execCommand("copy"),document.body.removeChild(n),e.textContent="✓",setTimeout(()=>{e.textContent="📋"},1500)}})})}function D(e,t){const n=document.getElementById("btn-apply");!n||!e||n.addEventListener("click",async()=>{n.disabled=!0,n.innerHTML='<span class="loading-dots">Trying codes</span>',await chrome.tabs.sendMessage(e,{type:"TRY_COUPONS"}),setTimeout(()=>f(),4e3)})}function g(e){return`
    <div class="submit-section">
      <div class="submit-title">💡 Know a working code? Share it!</div>
      <div class="submit-row">
        <input type="text" class="input-code" id="input-submit-code"
          placeholder="e.g. SAVE20"
          maxlength="30"
          autocomplete="off"
          spellcheck="false" />
        <button class="btn-submit" id="btn-submit-code">Submit</button>
      </div>
      <div class="submit-feedback" id="submit-feedback"></div>
    </div>
  `}function y(e){const t=document.getElementById("input-submit-code"),n=document.getElementById("btn-submit-code"),o=document.getElementById("submit-feedback");!t||!n||!o||(t.addEventListener("input",()=>{const s=t.selectionStart;t.value=t.value.toUpperCase().replace(/[^A-Z0-9\-_]/g,""),t.setSelectionRange(s,s)}),n.addEventListener("click",async()=>{const s=t.value.trim();if(!s||s.length<2){p(o,"Enter a valid code","error");return}n.disabled=!0,await T(e,s,"")?(t.value="",p(o,`✓ "${s}" saved! It'll be tried next checkout.`,"success"),setTimeout(()=>f(),1500)):p(o,"This code is already in the list.","error"),n.disabled=!1}),t.addEventListener("keydown",s=>{s.key==="Enter"&&n.click()}))}function p(e,t,n){e.textContent=t,e.className=`submit-feedback ${n}`,setTimeout(()=>{e.textContent="",e.className="submit-feedback"},4e3)}async function M(){try{const e=await chrome.storage.local.get(["savings_cents","coupons_applied","total_checkout_sessions","total_codes_tried"]),t=e.savings_cents||0,n=e.coupons_applied||0,o=e.total_checkout_sessions||0,s=e.total_codes_tried||0,i=document.getElementById("savings-strip"),a=document.getElementById("savings-amount"),d=document.getElementById("savings-rate");if(!i||!a)return;if((t>0||n>0)&&(t>0?a.textContent="$"+(t/100).toFixed(2):a.textContent=n+" coupon"+(n>1?"s":""),i.style.display="flex",d&&o>=3)){const u=Math.round(n/o*100);d.textContent=`${u}% success rate · ${o} sessions`,d.style.display="block"}const l=document.getElementById("btn-share-savings");l&&l.addEventListener("click",()=>{const u=t>0?"$"+(t/100).toFixed(2):n+" coupon"+(n>1?"s":""),E=t>0?`I saved ${u} shopping online with @CouponSnap! 🎉 Free Chrome extension that automatically finds & applies coupon codes: ${r} #savings #frugal`:`CouponSnap auto-applied ${u} for me while shopping! Free Chrome extension: ${r} #savings`;chrome.tabs.create({url:w(E)})})}catch{}}function w(e){return"https://twitter.com/intent/tweet?text="+encodeURIComponent(e)}function N(e,t){const n=t.replace(/^www\./,""),s=e?`I saved ${e||"money"} on ${n} with @CouponSnap! 🎉 It automatically found and applied the coupon code for me. Get it free: ${r} #savings #deals`:`Just used @CouponSnap on ${n} — free Chrome extension that auto-applies coupon codes at checkout! ${r} #savings`;return`
    <div class="share-prompt">
      <div class="share-prompt-title">🎉 Tell a friend and help them save too!</div>
      <div class="share-buttons">
        <button class="btn-tweet" data-tweet="${encodeURIComponent(s)}">𝕏 Tweet this</button>
        <button class="btn-copy-link" id="btn-copy-ext-link">Copy link</button>
      </div>
    </div>
  `}function H(){document.querySelectorAll(".btn-tweet").forEach(t=>{t.addEventListener("click",()=>{const n=w(decodeURIComponent(t.dataset.tweet));chrome.tabs.create({url:n})})});const e=document.getElementById("btn-copy-ext-link");e&&e.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(r),e.textContent="✓ Copied!",setTimeout(()=>{e.textContent="Copy link"},2e3)}catch{}})}async function W(){var e;try{if((await chrome.storage.local.get("onboarding_seen")).onboarding_seen)return;const n=document.getElementById("onboarding-overlay");if(!n)return;n.style.display="flex",(e=document.getElementById("btn-get-started"))==null||e.addEventListener("click",async()=>{n.style.display="none",await chrome.storage.local.set({onboarding_seen:!0})})}catch{}}async function f(){try{const e=await I();if(!(e!=null&&e.id)||!(e!=null&&e.url)||!e.url.startsWith("http")){b();return}const t=new URL(e.url).hostname,n=await _(e.id);await F(t,n,e.id)}catch{b()}}var h;(h=document.getElementById("link-feedback"))==null||h.addEventListener("click",e=>{e.preventDefault(),chrome.tabs.create({url:x})});B();W();M();f();
