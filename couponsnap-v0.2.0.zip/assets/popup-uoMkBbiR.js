import{g,a as y,s as w}from"./coupons-nOhhNl07.js";(function(){const s=document.createElement("link").relList;if(s&&s.supports&&s.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))a(t);new MutationObserver(t=>{for(const i of t)if(i.type==="childList")for(const d of i.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&a(d)}).observe(document,{childList:!0,subtree:!0});function n(t){const i={};return t.integrity&&(i.integrity=t.integrity),t.referrerPolicy&&(i.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?i.credentials="include":t.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function a(t){if(t.ep)return;t.ep=!0;const i=n(t);fetch(t.href,i)}})();const c=document.getElementById("content"),r=document.getElementById("tabs"),E=document.getElementById("deals-count"),$=document.getElementById("codes-count");let o="deals";function h(){document.querySelectorAll(".tab-btn").forEach(e=>{e.addEventListener("click",()=>{o=e.dataset.tab,document.querySelectorAll(".tab-btn").forEach(s=>s.classList.toggle("active",s===e)),document.querySelectorAll(".tab-panel").forEach(s=>s.classList.toggle("active",s.id===`panel-${o}`))})})}async function T(){const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});return e}async function C(e){return new Promise(s=>{chrome.runtime.sendMessage({type:"GET_TAB_STATE",tabId:e},s)})}function f(){r.style.display="none",c.innerHTML=`
    <div class="status-card">
      <div class="status-icon">🛒</div>
      <div class="status-title">Browse to a shopping site</div>
      <div class="status-subtitle">CouponSnap finds deals and coupon codes automatically as you shop.</div>
    </div>
  `}async function L(e,s,n){const a=g(e),t=(a==null?void 0:a.deals)||[],i=await y(e);if(!t.length&&!i.length){r.style.display="none",c.innerHTML=`
      <div class="status-card">
        <div class="status-icon">🔍</div>
        <div class="status-title">No savings found for this site</div>
        <div class="status-subtitle">We don't have deals or codes for <strong>${e}</strong> yet. Know a code? Submit it below!</div>
      </div>
      ${m()}
    `,b(e);return}r.style.display="flex",E.textContent=t.length,$.textContent=i.length,(s==null?void 0:s.status)==="found"&&i.length?o="codes":t.length?o="deals":o="codes",document.querySelectorAll(".tab-btn").forEach(v=>{v.classList.toggle("active",v.dataset.tab===o)});const d=A(t),p=await I(i,s);c.innerHTML=`
    <div class="tab-panel ${o==="deals"?"active":""}" id="panel-deals">
      ${d}
    </div>
    <div class="tab-panel ${o==="codes"?"active":""}" id="panel-codes">
      ${p}
      ${m()}
    </div>
  `,P(e,a),x(n),b(e)}function A(e,s,n){return e.length?`<div class="deal-list">${e.map((t,i)=>`
    <div class="deal-card">
      <div class="deal-info">
        <span class="deal-discount">${t.discount}</span>
        <div class="deal-desc">${t.desc}</div>
      </div>
      <button class="btn-shop" data-deal-index="${i}">Shop →</button>
    </div>
  `).join("")}</div>`:'<div class="empty-state"><div class="icon">🏷️</div>No deals available right now.</div>'}function P(e,s){document.querySelectorAll(".btn-shop").forEach(n=>{n.addEventListener("click",async()=>{const[a]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(a!=null&&a.url))return;let t=a.url;try{const i=new URL(t),d=B(s);d&&(i.searchParams.set(d.affiliateParam||d.param,d.affiliateTag||d.tag),t=i.toString())}catch{}chrome.tabs.update(a.id,{url:t}),window.close()})})}function B(e){return e!=null&&e.affiliateTag?{affiliateParam:e.affiliateParam,affiliateTag:e.affiliateTag}:null}async function I(e,s,n,a){if(!e.length)return'<div class="empty-state"><div class="icon">🏷️</div>No codes yet — be the first to submit one!</div>';let t="";(s==null?void 0:s.status)==="found"?t=`<button class="btn-primary" id="btn-apply">⚡ Try ${e.length} Code${e.length>1?"s":""} Automatically</button>`:(s==null?void 0:s.status)==="trying"?t='<button class="btn-primary" disabled><span class="loading-dots">Trying codes</span></button>':(s==null?void 0:s.status)==="applied"?t=`
      <div class="success-badge">
        <div class="code">${s.appliedCode}</div>
        <div class="desc">${s.savings?`Saved ${s.savings}`:"Coupon applied!"}</div>
        ${s.savings?`<span class="savings-pill">${s.savings} OFF</span>`:""}
      </div>
    `:(s==null?void 0:s.status)==="failed"&&(t=`
      <div class="status-card">
        <div class="status-icon">😞</div>
        <div class="status-title">No codes worked this time</div>
        <div class="status-subtitle">Know a working code? Submit it below!</div>
      </div>
    `);const i=e.map(d=>`
    <div class="code-card ${d.userSubmitted?"user-submitted":""}">
      <div class="code-meta">
        <div class="code-badge">${d.code}</div>
        <div class="code-desc">${d.desc}</div>
        ${d.userSubmitted?'<div class="user-badge">👤 Community</div>':""}
      </div>
      <span class="code-discount">${d.discount}</span>
    </div>
  `).join("");return`
    ${t}
    <div class="code-list" style="margin-top:${t?"10px":"0"}">${i}</div>
  `}function x(e,s){const n=document.getElementById("btn-apply");!n||!e||n.addEventListener("click",async()=>{n.disabled=!0,n.innerHTML='<span class="loading-dots">Trying codes</span>',await chrome.tabs.sendMessage(e,{type:"TRY_COUPONS"}),setTimeout(()=>u(),4e3)})}function m(e){return`
    <div class="submit-section">
      <div class="submit-title">💡 Know a working code? Share it!</div>
      <div class="submit-row">
        <input type="text" class="input-code" id="input-submit-code"
          placeholder="e.g. SAVE20"
          maxlength="30"
          autocomplete="off"
          spellcheck="false" />
        <button class="btn-submit" id="btn-submit-code">Submit</button>
      </div>
      <div class="submit-feedback" id="submit-feedback"></div>
    </div>
  `}function b(e){const s=document.getElementById("input-submit-code"),n=document.getElementById("btn-submit-code"),a=document.getElementById("submit-feedback");!s||!n||!a||(s.addEventListener("input",()=>{const t=s.selectionStart;s.value=s.value.toUpperCase().replace(/[^A-Z0-9\-_]/g,""),s.setSelectionRange(t,t)}),n.addEventListener("click",async()=>{const t=s.value.trim();if(!t||t.length<2){l(a,"Enter a valid code","error");return}n.disabled=!0,await w(e,t,"")?(s.value="",l(a,`✓ "${t}" saved! It'll be tried next checkout.`,"success"),setTimeout(()=>u(),1500)):l(a,"This code is already in the list.","error"),n.disabled=!1}),s.addEventListener("keydown",t=>{t.key==="Enter"&&n.click()}))}function l(e,s,n){e.textContent=s,e.className=`submit-feedback ${n}`,setTimeout(()=>{e.textContent="",e.className="submit-feedback"},4e3)}async function u(){try{const e=await T();if(!(e!=null&&e.id)||!(e!=null&&e.url)||!e.url.startsWith("http")){f();return}const s=new URL(e.url).hostname,n=await C(e.id);await L(s,n,e.id)}catch{f()}}h();u();
